import requests
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
from pprint import pprint
import json

ua = UserAgent()

url = "https://books.toscrape.com"
headers = {"User-Agent": ua.chrome}
session = requests.session()

books = []

current_page = 1

while True:
    page_url = f'{url}/catalogue/page-{current_page}.html'
    response = session.get(page_url, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")
    posts = soup.find_all('article', {'class': 'product_pod'})
    if not posts:
        break
    for post in posts:
        post_info = {}

        name_info = post.find('h3').find('a')['title']
        post_info['name'] = name_info
        books_url = url+'/catalogue/'+post.find('h3').find('a')['href']
        post_info['url'] = books_url

        price_info = post.find('p', {'class': 'price_color'})
        if price_info:
                price_string = price_info.getText().strip()
                # Удаляем всё, кроме цифр и точки
                clean_price = ''.join(filter(lambda x: x.isdigit() or x == '.', price_string))
                try:
                        post_info['price'] = float(clean_price)
                except ValueError:
                        print(f"Не удалось преобразовать цену: {clean_price}")
                        post_info['price'] = 0.0  # Назначаем дефолтное значение, если преобразование невозможно
        else:
                post_info['price'] = 0.0  # Если цена не найдена, назначаем нулевое значение
        book_response = session.get(books_url, headers=headers)
        book_soup = BeautifulSoup(book_response.text, "html.parser")

# Наличие книги
        availability_element = book_soup.select_one(".availability")
        if availability_element:
            post_info["available"] = availability_element.get_text(strip=True)
        else:
            post_info["available"] = "Unknown"

# Описание книги
        description_element = book_soup.find(id="product_description")
        if description_element:
            description_content = description_element.find_next_sibling("p")
            if description_content:
                post_info["description"] = description_content.get_text(strip=True)
            else:
                post_info["description"] = ""
        else:
            post_info["description"] = ""

# Добавляем информацию о книге в список
        books.append(post_info)

# Переходим на следующую страницу
    current_page += 1

# Выводим результат
pprint(books)

with open ('output.json', 'w', encoding='utf-8') as file:
    json.dump(books, file, ensure_ascii=False, indent=4)