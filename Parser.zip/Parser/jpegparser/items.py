# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy

# from itemloaders.processors import TakeFirst, MapCompose, Compose

class JpegparserItem(scrapy.Item):
    # define the fields for your item here like:
    name = scrapy.Field()
    url = scrapy.Field()
    category = scrapy.Field()
    photos = scrapy.Field()
