import scrapy
from scrapy.http import HtmlResponse
from jpegparser.items import JpegparserItem
from scrapy.loader import ItemLoader


class JpeggSpider(scrapy.Spider):
    name = "jpegg"
    allowed_domains = ["unsplash.com"]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.start_urls = [f"https://unsplash.com/t/{kwargs.get('query')}"]

    def parse(self, response: HtmlResponse):
        links = response.xpath("//a[@class='mG0SP']")
        for link in links:
            yield response.follow(link, callback=self.parse_picture)

    def parse_picture(self, response: HtmlResponse):
        # name = response.xpath("//h1/text()").get()
        # url = response.url
        # category = response.xpath("//a[@class='qOAId yZhvJ FTKrh']/text()").get()
        # photos = response.xpath("//img/@src[1]").getall()
        # yield(JpegparserItem(name=name, url=url, category=category, photos=photos))

        loader = ItemLoader(item=JpegparserItem(), response=response)
        loader.add_xpath('name', "//h1/text()")
        loader.add_value('url', response.url)
        loader.add_xpath('category', "//a[@class='qOAId yZhvJ FTKrh']/text()")
        loader.add_xpath('photos', "//img/@src[1]")
        yield loader.load_item()
